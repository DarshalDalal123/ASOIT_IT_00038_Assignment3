<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
         $(document).ready(function() {  
             $("#submit1").click(function() {  
                $("#FeedbackForm").each(function(){
                    if(this.val()=="")
                    {
                        $("#error_msg").html("Field needs filling");
                    }
                }); 
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card-group mb-0">
                    <div class="card p-4 mt-4" style="border-radius: 10px; background-color: yellow;">
                        <div class="card-body">
                        <form method="post" id="FeedbackForm" name="FeedbackForm">
                            <h1>Feedback Form</h1>
                            <div class="input-group-addon mb-3">
                                <span class="input-group-addon">Enter Name:-</span>
                                <input type="text"class="form-control" placeholder="Name" name="name">
                            </div>
                            <div class="input-group-addon mb-3">
                                <span class="input-group-addon">Enter Phone Number:-</span>
                                <input type="text" class="form-control" placeholder="Age" name="phonenumber">
                            </div>
                            <div class="input-group-addon mb-3">
                                <span class="input-group-addon">Enter Email:-</span>
                                <input type="email" class="form-control" placeholder = "Your Email" name="email">
                            </div>
                            <div class="group mb-3">
                                <div class="input-group-addon mb-3">
                                    <span class="input-group-addon">Your Experience:-</span>
                                    <br>
                                    <input type="radio" class="form-check-input" id="radio1" name="optradio" value="Very Good"> &nbsp; Very Good
                                    <label class="form-check-label" for="radio1"></label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" class="form-check-input" id="radio2" name="optradio" value="Good">&nbsp; Good
                                    <label class="form-check-label" for="radio2"></label> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;                                               
                                    <input type="radio" class="form-check-input" id="radio3" name="optradio" value="Bad">&nbsp; Bad
                                    <label class="form-check-label" for="radio3"></label> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" class="form-check-input" id="radio4" name="optradio" value="Very Bad">&nbsp; Very Bad
                                    <label class="form-check-label" for="radio4"></label> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div class="group mb-3">
                                <div class="input-group-addon mb-3">
                                    <span class="input-group-addon">Your Expectations:-</span>
                                    <br>
                                    <input type="radio" class="form-check-input" id="radio1" name="optradio1" value="1"> &nbsp; 1
                                    <label class="form-check-label" for="radio1"></label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" class="form-check-input" id="radio2" name="optradio1" value="2">&nbsp; 2
                                    <label class="form-check-label" for="radio2"></label> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;                                               
                                    <input type="radio" class="form-check-input" id="radio3" name="optradio1" value="3">&nbsp; 3
                                    <label class="form-check-label" for="radio3"></label> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" class="form-check-input" id="radio4" name="optradio1" value="4">&nbsp; 4 
                                    <label class="form-check-label" for="radio4"></label> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-outline-success" name="submit" id="submit1">Submit Form</button>
                                <button type="reset" class="btn btn-outline-danger">Clear Form</button>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    <?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "feedbackform";
$conn = mysqli_connect($servername,$username,$password,$database);
if(!$conn)
{
    die("Sorry We Failed To Connect".mysqli_connect_error());
}
else
{
    echo "Connection Was Successfull";
}
if(isset($_POST['submit']))
{
    $a = $_POST['name']; 
    $b = $_POST['phonenumber'];
    $c = $_POST['email'];
    $d = $_POST['optradio'];  
    $e = $_POST['optradio1']; 
}
$sql = "INSERT INTO `feedback` (`name`, `phone_num`, `email` ,`experience`, `expectations`) VALUES ('$a', '$b', '$c', '$d', '$e')";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "<br>Record Was Inserted Successfully";
}
else
{
    echo "<br>Record Was Not Inserted";
}
?>
</body>
</html>