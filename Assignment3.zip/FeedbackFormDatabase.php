<?php
$servername = "localhost";
$username = "root";
$password = "";
$conn = mysqli_connect($servername,$username,$password);
if(!$conn)
{
    die("Sorry We Failed To Connect".mysqli_connect_error());
}
else
{
    echo "Connection Was Successfull";
}
$sql = "CREATE DATABASE feedbackform";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "<br>Table Was Created Successfully";
}
else
{
    echo "<br>Table Was Not Created";
}
?>