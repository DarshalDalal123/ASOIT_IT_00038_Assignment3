<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "feedbackform";
$conn = mysqli_connect($servername,$username,$password,$database);
if(!$conn)
{
    die("Sorry We Failed To Connect<br>".mysqli_connect_error());
}
else
{
    echo "Connection Was Successfull<br>";
}

$sql = "CREATE TABLE `feedback` (`sno` INT(6) NOT NULL AUTO_INCREMENT , `name` VARCHAR(50) NOT NULL, `phone_num` VARCHAR(20) NOT NULL , `email` VARCHAR(50) NOT NULL, `experience` VARCHAR(20) NOT NULL, `expectations` VARCHAR(20) NOT NULL, PRIMARY KEY (`sno`))";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "Table Was Created Successfully";
}
else
{
    echo "Table Was Not Created";
}
?>